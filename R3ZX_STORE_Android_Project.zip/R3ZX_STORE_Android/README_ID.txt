R3ZX STORE - PROYEK APK ANDROID

Isi proyek ini membungkus file index.html website R3ZX STORE ke dalam aplikasi Android WebView.
Tampilan dan fitur website dipertahankan dari file index.html yang tersedia saat proyek dibuat.

CARA BUILD MENJADI APK:
1. Ekstrak ZIP ini.
2. Buka Android Studio di komputer/laptop.
3. Pilih Open lalu pilih folder R3ZX_STORE_Android.
4. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh komponen yang diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, tekan Locate pada notifikasi untuk menemukan app-debug.apk.

CATATAN:
- Ini adalah proyek sumber Android, belum berupa APK yang siap dipasang.
- Perlu Android Studio/Android SDK untuk membangun APK. Lingkungan saat proyek ini dibuat tidak memiliki Android SDK/Gradle, jadi APK biner tidak dapat dikompilasi di sini.
- Tombol order membuka WhatsApp/browser melalui aplikasi Android.
- Pembayaran DANA/QRIS tetap berupa pilihan dalam formulir order; proyek ini tidak memproses pembayaran otomatis.
